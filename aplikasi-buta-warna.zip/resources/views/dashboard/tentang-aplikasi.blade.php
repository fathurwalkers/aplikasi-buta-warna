@extends('layouts.dashboard-layouts')

@section('title', 'Dashboard - Aplikasi Tes Buta Warna')

@push('css')

@endpush


@section('main-content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">

                    {{-- <div class="row mb-2">
                        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                            <img class="img" src="{{ asset('img') }}/eye1.jpg" alt="" width="65%">
                        </div>
                    </div> --}}

                    <h5>Aplikasi Test Buta Warna</h5>
                    <p>
                        Aplikasi ini dibuat untuk penelitian tugas akhir.
                    </p>
                    <p>
                        <b>WAWAN - 17 650 054</b>
                    </p>

                    {{-- <hr /> --}}

                </div>
            </div>
        </div>
    </div>
@endsection


@push('css')

@endpush
