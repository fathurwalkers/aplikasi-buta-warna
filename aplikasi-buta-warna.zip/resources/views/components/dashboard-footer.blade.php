<div>
    <footer>
        <div class="container-fluid bg-primary fixed-bottom">
            <ul>
                <li><a href="{{ route('dashboard') }}"><i class="bi bi-house-fill text-light "></i></a>Home</li>
                {{-- <li><a href="{{ asset('login-assets') }}/jadwal.html"><i class="bi bi-list-stars text-light"></i></a>Jadwal</li>
                <li><a href="{{ asset('login-assets') }}/absen.html"><i class="bi bi-person-check text-light "></i></a>Absen</li> --}}
                <li><a href="{{ route('profile') }}"><i class="bi bi-person-circle text-light"></i></a>profil</li>
                <li><a href="{{ route('logout') }}"><i class="bi bi-backspace-reverse text-light"></i></a>Keluar</li>
            </ul>
        </div>
    </footer>
</div>
