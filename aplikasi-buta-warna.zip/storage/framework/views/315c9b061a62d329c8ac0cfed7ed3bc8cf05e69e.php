<?php $__env->startSection('title', 'Dashboard - Aplikasi Tes Buta Warna'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">

                    

                    <h5>Aplikasi Test Buta Warna</h5>
                    <p>
                        Aplikasi ini dibuat untuk penelitian tugas akhir.
                    </p>
                    <p>
                        <b>WAWAN - 17 650 054</b>
                    </p>

                    

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/dashboard/tentang-aplikasi.blade.php ENDPATH**/ ?>