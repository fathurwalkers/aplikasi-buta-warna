<?php $__env->startSection('title', 'Dashboard - Aplikasi Tes Buta Warna'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">

                    

                    <h5 class="text-center">PROFILE PENGGUNA</h5>
                    <p>
                        Informasi Data Pengguna. <br />
                    </p>
                    <table class="table table-borderless">
                        <tbody>

                            <tr style="">
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">Nama</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">:</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;"> <?php echo e($data->login_nama); ?></td>
                            </tr>

                            <tr style="">
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">Email</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">:</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;"> <?php echo e($data->login_email); ?></td>
                            </tr>

                            <tr style="">
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">Username</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">:</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;"> <?php echo e($data->login_username); ?></td>
                            </tr>

                            <tr style="">
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">No. HP / Telepon</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;">:</td>
                                <td class="" style="padding-top:auto;padding-bottom:auto;padding-top:1px;padding-bottom:1px;"> <?php echo e($data->login_telepon); ?></td>
                            </tr>

                        </tbody>
                    </table>

                </div>
            </div>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/dashboard/profile.blade.php ENDPATH**/ ?>