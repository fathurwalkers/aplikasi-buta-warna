<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/css/style.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/feather/feather.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/mdi/css/materialdesignicons.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/ti-icons/css/themify-icons.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/typicons/typicons.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/simple-line-icons/css/simple-line-icons.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/css/vendor.bundle.base.css" />
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
      integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/vendors/datatables.net-bs4/dataTables.bootstrap4.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/js/select.dataTables.min.css" />
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('login-assets')); ?>/css/vertical-layout-light/style.css" />
    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(asset('login-assets')); ?>/images/favicon.png" />

    <?php echo $__env->yieldPushContent('css'); ?>

  </head>
  <body>
    <!-- navbar -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard-navbar','data' => []]); ?>
<?php $component->withName('dashboard-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <!-- akhir navbar -->

    <!-- konten -->
    
    <div class="container" style="margin-top: 120px; margin-bottom: 120px;">

        <div class="row row-cols-1 justify-content-center mx-auto">
            <div class="col-sm-12 col-md-12 col-lg-12 justify-content-center mx-auto">
                <?php echo $__env->yieldContent('header-content'); ?>
            </div>
        </div>

        <?php echo $__env->yieldContent('main-content'); ?>
    </div>
    <!-- akhir konten -->

    <!-- footer -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dashboard-footer','data' => []]); ?>
<?php $component->withName('dashboard-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <!-- akhir footer -->

    <!-- akhir footer -->
    <!-- plugins:js -->
    <script src="<?php echo e(asset('login-assets')); ?>/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo e(asset('login-assets')); ?>/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/vendors/progressbar.js/progressbar.min.js"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('login-assets')); ?>/js/off-canvas.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/js/hoverable-collapse.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/js/template.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/js/settings.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('login-assets')); ?>/js/dashboard.js"></script>
    <script src="<?php echo e(asset('login-assets')); ?>/js/Chart.roundedBarCharts.js"></script>
    <!-- End custom js for this page-->
    <?php echo $__env->yieldPushContent('js'); ?>
  </body>
</html>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/layouts/dashboard-layouts.blade.php ENDPATH**/ ?>