<?php $__env->startSection('title', 'Dashboard - Aplikasi Tes Buta Warna'); ?>

<?php $__env->startPush('css'); ?>
<style>
    .red{
        background-color:red;
    }
    .blue{
        background-color:blue;
    }
    .gray{
        background:lightgray;
    }
    .box{
        float:left;
        border-radius: 8px;
        border: 2px solid lightgray;
        margin: 1px;
        width:30px;
        height:30px;
        border-radius:2px;
        background:white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <p class="text-center" id="p">Test buta Warna</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="row row-cols-1 justify-content-center mx-auto mb-2">
        <div class="col-sm-12 col-md-12 col-lg-12">
            
            

            <div id="elemendefault1" class="box" data-id="1" data-warna="1" style="background:lightgray;"></div>
            <?php $__currentLoopData = $acak_warna; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="elemendefault2" class="box" data-id="<?php echo e($item[1]); ?>" data-warna="<?php echo e($item[1]); ?>" style="background:<?php echo e($item[0]); ?>;"></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>
    </div>
    <div class="row row-cols-1 justify-content-center mx-auto mb-4">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div id="elemendefault17" class="box" data-id="0" data-warna="1" style="background:rgb(55,129,193);"></div>
            <div id="elemendefault18" class="box" data-id="0" data-warna="0" onclick="" style="background:white"></div>
            <div id="elemendefault19" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault20" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault21" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault22" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault23" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault24" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault25" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault26" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault27" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault28" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault29" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault30" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault31" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
            <div id="elemendefault32" class="box" data-id="0" data-warna="0" onclick="" style="background:white;"></div>
        </div>
    </div>
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row row-cols-1 d-flex justify-content-center mx-auto my-2">
            <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center mx-auto">
                <button id="buttonhasil" class="btn btn-success d-flex justify-content-center mx-auto">PROSES</button>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script type="text/javascript" charset="utf-8">
        $(document).ready(function() {
            let arrayHasil = new Array();
            let pallete=document.querySelectorAll('.box');
            var arrayResult = ['1'];
            let arrayBoxKosong = [17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32];
            let arrayJawaban = [1, 2 ,3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];
            let ambilid = 0;
            let ambilwarna = 0;
            let ambilbg = 0;
            pallete.forEach(e => {
                e.addEventListener("click",function(e){
                    let idbox=e.target.dataset.id;
                    let warna=e.target.dataset.warna;
                    let bgstyle=e.target.style.background;
                    if(warna > 0) {
                        ambilid = idbox;
                        ambilwarna = warna;
                        ambilbg = bgstyle;
                    }
                    else {
                        arrayResult.push(ambilid);
                        console.log(arrayResult);

                        e.target.dataset.id = ambilid;
                        e.target.dataset.warna = ambilwarna;
                        e.target.style.background = ambilbg;
                        ambilwarna = 0;
                        ambilbg = 0;
                        ambilid = 0;
                    }
                });
            });
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('[name=_token]').val()
                }
            });
            $("#buttonhasil").click(function(a) {
                a.preventDefault();
                let _token   = $('[name=_token]').val()
                let jsonparsearray = JSON.stringify(arrayResult);
                for (let i = 0; i < arrayBoxKosong.length; i++) {
                    let idtiapbox = "#elemendefault"+arrayBoxKosong[i];
                    let getbox = $(idtiapbox).data("warna");
                    console.log(idtiapbox);
                    console.log(getbox);
                    arrayHasil.push(getbox);
                }
                var benar = 0;
                var salah = 0;
                for (let j = 0; j < 16; j++) {
                    if (arrayHasil[j] == arrayJawaban[j]) {
                        benar++;
                    } else {
                        salah++;
                    }
                }
                var totalnilai=(benar/16)*100;
                console.log("TOTAL BENAR");
                console.log(totalnilai);
                console.log("Benar");
                console.log(benar);
                console.log("Salah");
                console.log(salah);
                redirect_to = "<?php echo e(route('dashboard')); ?>/get-proses-hasil" + "/" + totalnilai + "/" + benar + "/" + salah;
                window.location.assign(redirect_to);
                // $.ajax({
                //     type: "POST",
                //     url: "<?php echo e(route('proses-hasil')); ?>",
                //     dataType: 'JSON',
                //     data: {
                //         data: totalnilai,
                //         _token: _token
                //     },
                //     success: window.location.assign(redirect_to);
                //     // success: function(data) {
                //     //     // console.log(data);
                //     //     redirect_to = "<?php echo e(route('dashboard')); ?>/get-proses-hasil" + "/" + totalnilai;
                //     //     window.location.href = redirect_to;
                //     //     alert("success");
                //     // }
                // });
                // console.log(totalnilai);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/dashboard/test-buta-warna.blade.php ENDPATH**/ ?>