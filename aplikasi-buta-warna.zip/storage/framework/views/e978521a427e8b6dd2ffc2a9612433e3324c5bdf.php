<?php $__env->startSection('title', 'Dashboard - Aplikasi Tes Buta Warna'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-content'); ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mb-2">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">KODE TEST : <?php echo e($item->hasil_kode); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted">Tanggal Test : <?php echo e(date("d, M Y", strtotime($item->hasil_waktu))); ?></h6>
                    <p class="card-text">Status : <?php echo e($item->hasil_status); ?></p>

                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-end">
                            <button onclick="location.href = '<?php echo e(route('lihat-hasil-test', $item->id)); ?>';" class="btn btn-md btn-info d-flex justify-content-end">Lihat</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/dashboard/riwayat-test.blade.php ENDPATH**/ ?>