<div>
    <nav class="navbar navbar-dark bg-primary shadow mb-5 fixed-top" style="height:85px;">
        <div class="container">
            <a class="navbar-brand" href="#">
                    
                    <h6 style=" font: size 15px; display: inline;">DiagnosaWarna</h6>
            </a>
          <span class="navbar-text" style="margin-left: auto; font-size: 12px;">
              Hai, <?php echo e($users->login_nama); ?> &nbsp;
        </span>
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-item" href="#">
                        
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/components/dashboard-navbar.blade.php ENDPATH**/ ?>