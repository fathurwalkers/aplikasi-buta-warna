<div>
    <footer>
        <div class="container-fluid bg-primary fixed-bottom">
            <ul>
                <li><a href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-house-fill text-light "></i></a>Home</li>
                
                <li><a href="<?php echo e(route('profile')); ?>"><i class="bi bi-person-circle text-light"></i></a>profil</li>
                <li><a href="<?php echo e(route('logout')); ?>"><i class="bi bi-backspace-reverse text-light"></i></a>Keluar</li>
            </ul>
        </div>
    </footer>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/components/dashboard-footer.blade.php ENDPATH**/ ?>