<?php $__env->startSection('title', 'Dashboard - Aplikasi Tes Buta Warna'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row row-cols-1  justify-content-center">

        <div class="col-10 mb-4 btn shadow ">
            <a href="<?php echo e(route('informasi')); ?>">
                <div class="card border-primary">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-primary btn-sm" >
                            <i class="bi bi-box-arrow-in-right" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold" style="font-size: 1rem; display: inline-block; margin-left: 40px;">INFORMASI</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('test-buta-warna')); ?>">
                <div class="card border-warning  ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-warning btn-sm">
                            <i class="bi bi-list-stars text-light" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-warning" style=" font-size: 1rem; display: inline-block; margin-left: 40px;">MULAI TES</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('tentang-aplikasi')); ?>">
                <div class="card border-success ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-success btn-sm">
                            <i class="bi bi-award" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-success" style="font-size: 1rem; display: inline-block; margin-left: 40px;">TENTANG APLIKASI</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-10 mb-4 btn shadow">
            <a href="<?php echo e(route('riwayat-test')); ?>">
                <div class="card border-info ">
                    <div class="card-body text-left">
                        <button type="button" class="btn btn-info btn-sm">
                            <i class="bi bi-star-fill" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-info" style="font-size: 1rem; display: inline-block; margin-left: 40px;">RIWAYAT TES</h6>
                    </div>
                </div>
            </a>
        </div>

        <div class="col-10 mb-4 btn shadow">
            
                <form action="<?php echo e(route('logout')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                <div class="card border-danger ">
                    <div class="card-body text-left">
                        <button type="submit" class="btn btn-danger btn-sm">
                            <i class="bi bi-activity" style="font-size: 1rem; display:inline-block;"></i>
                        </button>
                        <h6 class="card-title font-weight-bold text-danger" style="font-size: 1rem; display: inline-block; margin-left: 40px;">KELUAR</h6>
                    </div>
                </div>
                </form>
            
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard-layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-buta-warna\resources\views/dashboard/index.blade.php ENDPATH**/ ?>